# Karabo Green Initiative — Part 2

## Student / Project
**Student:** Karabo Nkadimeng  
**Student Number:** ST10448477  
**Project:** Karabo Green Initiative website  
**Part:** 2 — Designing the Visuals: CSS Styling and Responsive Design  
**Year:** 2026

## 1. Part 2 Overview

Part 2 develops the HTML website from Part 1 into a styled, responsive desktop and mobile solution. An external stylesheet (`style.css`) is linked to all five HTML pages.

The website uses:
- CSS variables for a consistent colour system.
- Responsive typography using `clamp()` and relative units.
- Flexbox for navigation.
- CSS Grid for programme, feature and team layouts.
- Media queries for desktop, tablet and mobile breakpoints.
- Hover and focus states for interactive elements.
- Responsive images using `srcset` and `sizes`.
- Accessible focus indicators and a skip-to-content link.
- Mobile navigation that changes from a horizontal layout to a vertical layout.

## 2. Part 1 Feedback and Content Improvements

The Part 1 website structure has been retained, but the content and research have been strengthened for Part 2.

### Content and research changes
1. **More specific environmental guidance:** Programme content now gives visitors practical actions such as preventing waste, reducing unnecessary consumption, reusing suitable items, separating recyclable materials and disposing of waste responsibly.
2. **Research-informed content:** A new "Research-Informed Waste Guidance" section was added to the Programmes page. It is based on the South African Department of Forestry, Fisheries and the Environment (DFFE) and United Nations Environment Programme (UNEP).
3. **Clear distinction between fictional and factual information:** The website continues to identify Karabo Green Initiative as a fictional academic organisation. Environmental guidance is presented as original educational content informed by authoritative sources rather than as copied organisational material.
4. **Improved programme descriptions:** The five programmes now have clearer activities/topics so visitors can understand what each programme involves.
5. **Improved content consistency:** Page headings, navigation labels, calls to action and descriptions have been kept consistent across all pages.
6. **Image-path correction:** The homepage image reference was corrected from `hero.jpg` to the actual `Hero.jpg` filename so it works correctly on case-sensitive systems such as GitHub Pages.
7. **Missing image correction:** The Green Household programme now uses an available recycling image rather than referencing an image that was not included in Part 1.

## 3. CSS Implementation

### External stylesheet
All pages link to:

`style.css`

The stylesheet contains:
- Base/reset styles.
- Colour variables.
- Typography.
- Header and navigation styling.
- Grid and Flexbox layouts.
- Cards and visual styling.
- Forms and controls.
- Hover/focus/active-style interaction states.
- Responsive breakpoints.
- Reduced-motion support.

### Breakpoints
- **Desktop:** above 900px
- **Tablet:** 701px–900px
- **Mobile:** 700px and below

The exact breakpoints are based on content behaviour rather than a specific physical device model.

## 4. Responsive Design

The desktop layout uses multiple columns for suitable sections. At smaller widths, layouts collapse to one column where necessary.

Responsive techniques include:
- `%` and `min()` for container widths.
- `rem` for scalable spacing and typography.
- `clamp()` for responsive headings.
- `minmax()` and CSS Grid for flexible columns.
- Media queries at 900px and 700px.
- `max-width: 100%` for images.
- `srcset` and `sizes` for responsive image selection.
- Vertical mobile navigation.

The implementation also considers accessibility by keeping visible keyboard focus states and ensuring images remain within their available containers.

## 5. Testing Evidence

Before final LMS submission, capture and add three screenshots from browser
Developer Tools and place them in a `screenshots` folder:

- `desktop-1440.png` — desktop viewport, approximately 1440 × 900.
- `tablet-768.png` — tablet viewport, approximately 768 × 900.
- `mobile-390.png` — mobile viewport, approximately 390 × 844.

Testing should check:
- Navigation wrapping and mobile layout.
- Multi-column to single-column transitions.
- Image scaling.
- Text readability.
- Form width and usability.
- Horizontal overflow.

## 6. Changelog

### v2.0 — Part 2
- Added `style.css` as the external stylesheet for the complete website.
- Linked the stylesheet to `index.html`, `about.html`, `services.html`, `enquiry.html` and `contact.html`.
- Added a consistent green, earth-tone and white visual identity.
- Added responsive header and navigation.
- Added desktop Grid/Flexbox layouts.
- Added tablet and mobile media queries.
- Added responsive typography using relative units and `clamp()`.
- Added responsive images using `srcset` and `sizes`.
- Added hover and keyboard focus states.
- Added accessible skip navigation.
- Added responsive form styling.
- Added reduced-motion support.
- Added research-informed waste guidance to improve the environmental content.
- Expanded programme descriptions and practical waste-management guidance.
- Added research references to the README.
- Corrected the homepage `Hero.jpg` filename reference for case-sensitive hosting.
- Corrected the unavailable Green Household image reference.

### Part 1 feedback/content corrections carried into Part 2
- Research is now connected more clearly to the environmental education presented on the website.
- Content is more specific about what visitors can learn or do.
- The fictional status of the organisation is made clear to avoid presenting the academic scenario as a real organisation.
- Source-based environmental information is separated from fictional organisational information.

## 7. GitHub Workflow

Recommended commit sequence:

1. `Update Part 1 content based on feedback`
2. `Add external CSS stylesheet`
3. `Add responsive desktop tablet and mobile layouts`
4. `Improve responsive images and accessibility`
5. `Update README changelog and references`
6. `Add screenshot evidence for Part 2`

After committing, push the changes to the remote repository and submit the GitHub repository URL through the LMS.

## 8. References

Department of Forestry, Fisheries and the Environment (DFFE) (2020) *National Waste Management Strategy 2020*. Pretoria: Government of South Africa. Available at: https://www.dffe.gov.za/sites/default/files/docs/nationalwaste_management_strategy.pdf (Accessed: 18 September 2026).

Department of Forestry, Fisheries and the Environment (DFFE) (2025) *CWM strategy and framework*. Available at: https://www.dffe.gov.za/cwm_strategy.framework (Accessed: 18 September 2026).

United Nations Environment Programme (UNEP) (2021) *Waste Pollution 101*. Available at: https://www.unep.org/interactives/beat-waste-pollution/ (Accessed: 18 September 2026).

United Nations Environment Programme (UNEP) (2025) *Circularity: Redesigning Systems for a Regenerative Future*. Available at: https://www.unep.org/topics/finance-and-economic-transformations/scp-and-circularity/circularity-redesigning-systems (Accessed: 18 September 2026).

World Wide Web Consortium (W3C) (2026) *Using CSS max-width and height to fit images*. Web Accessibility Initiative. Available at: https://www.w3.org/WAI/WCAG22/Techniques/css/C37 (Accessed: 18 September 2026).

World Wide Web Consortium (W3C) (2017) *Use Cases and Requirements for Standardizing Responsive Images*. Available at: https://www.w3.org/TR/respimg-usecases/ (Accessed: 18 September 2026).

## 9. Project Structure

```text
Karabo_Green_Initiative_Part_2/
├── index.html
├── about.html
├── services.html
├── enquiry.html
├── contact.html
├── style.css
├── README.md
├── images/
└── screenshots/
```

> **Note:** The organisation and its locations/contact details are fictional and are included for academic project purposes.
